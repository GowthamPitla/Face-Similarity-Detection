document.addEventListener("DOMContentLoaded", () => {
    console.log("Page Loaded!");
});
